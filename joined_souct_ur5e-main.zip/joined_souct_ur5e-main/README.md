# joined_souct_ur5e
joined scout2.0 mobile platform and UR5e manipulator
